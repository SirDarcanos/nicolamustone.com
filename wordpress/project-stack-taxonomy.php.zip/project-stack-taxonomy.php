<?php
/**
 * Plugin Name:  Project Stack Taxonomy
 * Description:  Adds a reusable, tag-like "Stack" taxonomy to posts, exposed in
 *               the REST API. Lets the headless front-end read each project's
 *               tech stack the same way it reads tags.
 * Version:      1.0.0
 * Author:       Nicola Mustone
 * License:      MIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

add_action( 'init', function () {
	register_taxonomy(
		'stack',
		'post',
		array(
			'labels'            => array(
				'name'          => 'Stack',
				'singular_name' => 'Stack item',
				'add_new_item'  => 'Add stack item',
				'search_items'  => 'Search stack',
				'not_found'     => 'No stack items yet',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rest_base'         => 'stack',
		)
	);
} );
