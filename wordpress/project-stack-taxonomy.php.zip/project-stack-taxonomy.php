<?php
/**
 * Plugin Name:  Project Stack Taxonomy
 * Description:  Adds Stack taxonomy and highights post metas for the headless front end to read via REST API.
 * Version:      1.0.0
 * Author:       Nicola Mustone
 * License:      MIT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

add_action( 'init', function () {
	register_taxonomy(
		'stack',
		'post',
		array(
			'labels'            => array(
				'name'          => 'Stack',
				'singular_name' => 'Stack item',
				'add_new_item'  => 'Add stack item',
				'search_items'  => 'Search stack',
				'not_found'     => 'No stack items yet',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rest_base'         => 'stack',
		)
	);
} );

add_action( 'init', function () {
	register_post_meta( 'post', 'highlights', array(
		'type'         => 'string',
		'single'       => false,
		'show_in_rest' => true,
	) );
} );
